#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime, timezone
import argparse, json, hashlib, uuid, shutil, zipfile, csv, io

VERSION = "v18.26"
ROOT = Path.cwd()
BASE = ROOT / "cmcb_sync"

def now():
    return datetime.now(timezone.utc).isoformat()

def pid(prefix):
    return f"{prefix}_{uuid.uuid4().hex[:12]}"

def write_json(path, obj):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
    return p

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def sha256_file(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def append_jsonl(path, obj):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")

def init(args=None):
    for d in [
        "cmcb_sync/inbox_from_chatgpt", "cmcb_sync/outbox_to_chatgpt",
        "cmcb_sync/inbox_from_codex", "cmcb_sync/outbox_to_codex",
        "cmcb_sync/applied", "cmcb_sync/rejected", "cmcb_sync/conflicts",
        "cmcb_sync/ledger", "cmcb_sync/state", "cmcb_sync/checkpoints"
    ]:
        Path(d).mkdir(parents=True, exist_ok=True)
    state = {
        "sync_version": VERSION,
        "initialized_at": now(),
        "status": "initialized",
        "latest_codex_packet": None,
        "latest_chatgpt_packet": None,
        "waiting_for_chatgpt_ack": [],
        "waiting_for_codex_ack": [],
        "conflicts": []
    }
    if not Path("cmcb_sync/state/SYNC_STATE.json").exists():
        write_json("cmcb_sync/state/SYNC_STATE.json", state)
    print(json.dumps({"result": "INITIALIZED", "state": "cmcb_sync/state/SYNC_STATE.json"}, indent=2))

def validate_packet(packet):
    errors = []
    required = [
        "packet_id", "message_id", "sequence_number", "timestamp", "source_actor", "target_actor",
        "origin", "destination", "cmcb_version_from", "cmcb_version_to", "update_type",
        "summary", "files_changed", "files_added", "files_removed", "checksums", "validation",
        "apply_policy", "conflict_policy", "requires_ack", "expected_reply_channel", "status"
    ]
    for k in required:
        if k not in packet:
            errors.append(f"missing:{k}")
    if packet.get("source_actor") not in {"USER_MARTIN","CHATGPT_CENTRAL","CHATGPT_WORK_CHAT","CODEX_LOCAL","CODEX_CLOUD","CODEX_BRIDGE","CMCB_AUTOMATION","SERVER_PROCESS","UNKNOWN"}:
        errors.append("unknown_source_actor")
    if packet.get("target_actor") not in {"USER_MARTIN","CHATGPT_CENTRAL","CHATGPT_WORK_CHAT","CODEX_LOCAL","CODEX_CLOUD","CODEX_BRIDGE","CMCB_AUTOMATION","SERVER_PROCESS","UNKNOWN"}:
        errors.append("unknown_target_actor")
    return errors

def validate_structured_file(path):
    p = Path(path)
    lower = p.name.lower()
    try:
        if lower.endswith(".json"):
            json.loads(p.read_text(encoding="utf-8"))
            return {"file": str(p), "result": "PASS", "type": "json"}
        if lower.endswith(".jsonl"):
            for i, line in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
                if line.strip():
                    json.loads(line)
            return {"file": str(p), "result": "PASS", "type": "jsonl"}
        if lower.endswith(".csv"):
            list(csv.reader(io.StringIO(p.read_text(encoding="utf-8"))))
            return {"file": str(p), "result": "PASS", "type": "csv"}
        if lower.endswith(".zip"):
            with zipfile.ZipFile(p) as z:
                bad = z.testzip()
                if bad:
                    return {"file": str(p), "result": "FAIL", "type": "zip", "error": bad}
            return {"file": str(p), "result": "PASS", "type": "zip"}
    except Exception as e:
        return {"file": str(p), "result": "FAIL", "error": str(e)}
    return {"file": str(p), "result": "SKIPPED", "type": "other"}

def export_codex_update(args):
    init()
    changed = [Path(x) for x in args.files] if args.files else []
    checksums, validation = {}, []
    for f in changed:
        if f.exists() and f.is_file():
            checksums[str(f)] = sha256_file(f)
            validation.append(validate_structured_file(f))
    packet = {
        "packet_id": pid("codex_update"),
        "message_id": pid("msg"),
        "sequence_number": 1,
        "timestamp": now(),
        "source_actor": "CODEX_LOCAL",
        "target_actor": "CHATGPT_CENTRAL",
        "origin": "codex_workspace",
        "destination": "central_chat",
        "cmcb_version_from": args.from_version,
        "cmcb_version_to": args.to_version,
        "update_type": args.update_type,
        "summary": args.summary,
        "files_changed": [str(x) for x in changed],
        "files_added": [],
        "files_removed": [],
        "checksums": checksums,
        "validation": validation,
        "apply_policy": args.apply_policy,
        "conflict_policy": args.conflict_policy,
        "requires_ack": True,
        "expected_reply_channel": "cmcb_sync/inbox_from_chatgpt",
        "status": "ready_for_transfer"
    }
    errors = validate_packet(packet)
    packet["packet_validation"] = {"result": "PASS" if not errors else "FAIL", "errors": errors}
    out = Path("cmcb_sync/outbox_to_chatgpt") / (packet["packet_id"] + ".json")
    write_json(out, packet)
    append_jsonl("cmcb_sync/ledger/SYNC_LEDGER.jsonl", {"event": "export_codex_update", "timestamp": now(), "packet": str(out), "result": packet["packet_validation"]["result"]})
    make_chatgpt_import_prompt(None)
    print(json.dumps({"result": packet["packet_validation"]["result"], "packet": str(out)}, indent=2))

def make_chatgpt_import_prompt(args):
    outbox = sorted(Path("cmcb_sync/outbox_to_chatgpt").glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    packet_path = outbox[0] if outbox else None
    text = f"""CENTRAL CHAT — IMPORT CODEX CMCB UPDATE

A Codex-side CMCB update packet is ready.

Packet file:
{packet_path if packet_path else "No packet found."}

Required behavior:
1. Verify the CMCB_BIDIRECTIONAL_SYNC_PACKET fields.
2. Confirm source_actor=CODEX_LOCAL and target_actor=CHATGPT_CENTRAL.
3. Check cmcb_version_from/to, files_changed, checksums, validation, apply_policy, and conflict_policy.
4. Apply, record-only, reject, or request resync.
5. Return a CMCB_SYNC_RECEIPT packet for Codex.
6. Do not assume Codex-side and ChatGPT-side CMCB are aligned until receipt/ACK is produced.

If applying: update ChatGPT-side CMCB artifacts/memory pointer compactly and preserve detailed state in artifacts.
"""
    Path("cmcb_sync/outbox_to_chatgpt").mkdir(parents=True, exist_ok=True)
    Path("cmcb_sync/outbox_to_chatgpt/CENTRAL_CHAT_IMPORT_PROMPT.md").write_text(text, encoding="utf-8")
    return text

def import_chatgpt(args=None):
    init()
    inbox = sorted(Path("cmcb_sync/inbox_from_chatgpt").glob("*.json"))
    results = []
    for p in inbox:
        try:
            packet = read_json(p)
            errors = validate_packet(packet)
            if packet.get("target_actor") not in {"CODEX_LOCAL", "CODEX_BRIDGE", "CMCB_AUTOMATION"}:
                errors.append("target_not_codex_side")
            if errors:
                dest = Path("cmcb_sync/rejected") / p.name
                shutil.copy2(p, dest)
                results.append({"packet": str(p), "result": "REJECTED", "errors": errors})
                continue
            dest = Path("cmcb_sync/applied") / p.name
            shutil.copy2(p, dest)
            receipt = {
                "receipt_id": pid("receipt"),
                "received_packet_id": packet["packet_id"],
                "timestamp": now(),
                "source_actor": "CODEX_LOCAL",
                "target_actor": packet.get("source_actor", "CHATGPT_CENTRAL"),
                "validation_result": "PASS",
                "understood_action": packet.get("summary", ""),
                "apply_decision": "record_only" if packet.get("apply_policy") == "record_only" else "manual_review",
                "conflicts": [],
                "next_action": "Await explicit apply command if manual_review is required."
            }
            rpath = Path("cmcb_sync/outbox_to_chatgpt") / (receipt["receipt_id"] + ".receipt.json")
            write_json(rpath, receipt)
            results.append({"packet": str(p), "result": "IMPORTED", "applied_record": str(dest), "receipt": str(rpath)})
        except Exception as e:
            dest = Path("cmcb_sync/rejected") / p.name
            shutil.copy2(p, dest)
            results.append({"packet": str(p), "result": "ERROR", "error": str(e), "dest": str(dest)})
    report = {"result": "DONE", "timestamp": now(), "results": results}
    write_json("cmcb_sync/state/IMPORT_CHATGPT_REPORT.json", report)
    append_jsonl("cmcb_sync/ledger/SYNC_LEDGER.jsonl", {"event": "import_chatgpt", "timestamp": now(), "results": results})
    print(json.dumps(report, indent=2))

def make_chatgpt_update_packet(args):
    init()
    packet = {
        "packet_id": pid("chatgpt_update"),
        "message_id": pid("msg"),
        "sequence_number": 1,
        "timestamp": now(),
        "source_actor": "CHATGPT_CENTRAL",
        "target_actor": "CODEX_LOCAL",
        "origin": "central_chat",
        "destination": "codex_workspace",
        "cmcb_version_from": args.from_version,
        "cmcb_version_to": args.to_version,
        "update_type": args.update_type,
        "summary": args.summary,
        "files_changed": args.files,
        "files_added": [],
        "files_removed": [],
        "checksums": {},
        "validation": [],
        "apply_policy": args.apply_policy,
        "conflict_policy": args.conflict_policy,
        "requires_ack": True,
        "expected_reply_channel": "cmcb_sync/outbox_to_chatgpt",
        "status": "ready_for_transfer"
    }
    out = Path("cmcb_sync/outbox_to_codex") / (packet["packet_id"] + ".json")
    write_json(out, packet)
    print(json.dumps({"result": "CREATED", "packet": str(out)}, indent=2))

def status(args=None):
    init()
    report = {
        "result": "STATUS",
        "timestamp": now(),
        "outbox_to_chatgpt": len(list(Path("cmcb_sync/outbox_to_chatgpt").glob("*.json"))),
        "inbox_from_chatgpt": len(list(Path("cmcb_sync/inbox_from_chatgpt").glob("*.json"))),
        "outbox_to_codex": len(list(Path("cmcb_sync/outbox_to_codex").glob("*.json"))),
        "inbox_from_codex": len(list(Path("cmcb_sync/inbox_from_codex").glob("*.json"))),
        "applied": len(list(Path("cmcb_sync/applied").glob("*.json"))),
        "rejected": len(list(Path("cmcb_sync/rejected").glob("*.json"))),
        "conflicts": len(list(Path("cmcb_sync/conflicts").glob("*.json")))
    }
    write_json("cmcb_sync/state/SYNC_STATUS_REPORT.json", report)
    print(json.dumps(report, indent=2))

parser = argparse.ArgumentParser()
sub = parser.add_subparsers(dest="cmd")
sub.add_parser("init")
e = sub.add_parser("export-codex-update")
e.add_argument("--summary", required=True)
e.add_argument("--files", nargs="*", default=[])
e.add_argument("--from-version", default="unknown")
e.add_argument("--to-version", default=VERSION)
e.add_argument("--update-type", default="codex_workflow_update")
e.add_argument("--apply-policy", default="manual_review")
e.add_argument("--conflict-policy", default="merge_no_loss")
sub.add_parser("make-chatgpt-import-prompt")
sub.add_parser("import-chatgpt")
c = sub.add_parser("make-chatgpt-update-packet")
c.add_argument("--summary", required=True)
c.add_argument("--files", nargs="*", default=[])
c.add_argument("--from-version", default="unknown")
c.add_argument("--to-version", default=VERSION)
c.add_argument("--update-type", default="chatgpt_workflow_update")
c.add_argument("--apply-policy", default="manual_review")
c.add_argument("--conflict-policy", default="merge_no_loss")
sub.add_parser("status")
args = parser.parse_args()
if args.cmd == "init" or args.cmd is None:
    init()
elif args.cmd == "export-codex-update":
    export_codex_update(args)
elif args.cmd == "make-chatgpt-import-prompt":
    print(make_chatgpt_import_prompt(args))
elif args.cmd == "import-chatgpt":
    import_chatgpt(args)
elif args.cmd == "make-chatgpt-update-packet":
    make_chatgpt_update_packet(args)
elif args.cmd == "status":
    status(args)
else:
    parser.print_help()
