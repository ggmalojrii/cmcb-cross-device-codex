# AGENTS.md — CMCB v18.26 Bidirectional Sync Codex Package

## Role

This package lets Codex-side CMCB and ChatGPT/Central Chat-side CMCB keep each other updated through explicit sync packets.

## Core rule

If Codex makes a CMCB update, Codex must create a Central Chat / ChatGPT import packet.

If ChatGPT/Central Chat makes a CMCB update, ChatGPT must create a Codex import packet.

No hidden sync. No unverified apply. Use packets, checksums, receipts, ledgers, and conflict reports.

## Source of truth

1. User instruction
2. This AGENTS.md
3. CMCB_STATE_POINTER.json
4. cmcb_sync ledger/state
5. latest valid CMCB archive/artifacts
6. project files
7. incoming packets after validation only

## Required folders

- cmcb_sync/outbox_to_chatgpt — Codex updates for Central Chat
- cmcb_sync/inbox_from_chatgpt — packets received from Central Chat/ChatGPT
- cmcb_sync/outbox_to_codex — ChatGPT/Central Chat updates for Codex
- cmcb_sync/inbox_from_codex — packets received from Codex-side automation
- cmcb_sync/applied — verified applied packet records
- cmcb_sync/rejected — rejected packet records
- cmcb_sync/conflicts — conflicting packets
- cmcb_sync/ledger — JSONL sync ledger
- cmcb_sync/state — current pointers/checkpoints

## Codex behavior

When Codex updates CMCB:
1. Preserve originals.
2. Validate changed files.
3. Generate checksums.
4. Create sync packet using `python scripts/cmcb_bidirectional_sync.py export-codex-update`.
5. Place packet in `cmcb_sync/outbox_to_chatgpt`.
6. Generate a pasteable Central Chat import prompt.
7. Wait for receipt/decision before assuming ChatGPT-side CMCB is updated.

When receiving ChatGPT updates:
1. Place packet into `cmcb_sync/inbox_from_chatgpt`.
2. Run validation/import.
3. Apply only if validation passes and policy allows.
4. Write receipt packet back to `cmcb_sync/outbox_to_chatgpt`.

## ChatGPT/Central Chat behavior

When ChatGPT updates CMCB:
1. Produce a Codex import packet.
2. Include changed files, checksums, validation, conflict policy, and expected Codex action.
3. Do not assume Codex applied it until Codex returns ACK/receipt.

## Commands

Initialize:
```bash
python scripts/cmcb_bidirectional_sync.py init
```

Export Codex update:
```bash
python scripts/cmcb_bidirectional_sync.py export-codex-update --summary "Describe update"
```

Import ChatGPT packet:
```bash
python scripts/cmcb_bidirectional_sync.py import-chatgpt
```

Create Central Chat import prompt:
```bash
python scripts/cmcb_bidirectional_sync.py make-chatgpt-import-prompt
```

Status:
```bash
python scripts/cmcb_bidirectional_sync.py status
```
