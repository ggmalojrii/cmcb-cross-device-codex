# CMCB v18.26 Codex Drop-In

## Setup

Place this folder's contents into your Codex project root.

Run:

```bash
python scripts/cmcb_bidirectional_sync.py init
```

## If Codex updates CMCB

```bash
python scripts/cmcb_bidirectional_sync.py export-codex-update --summary "Codex-side CMCB update"
python scripts/cmcb_bidirectional_sync.py make-chatgpt-import-prompt
```

Paste `cmcb_sync/outbox_to_chatgpt/CENTRAL_CHAT_IMPORT_PROMPT.md` into Central Chat.

## If ChatGPT updates CMCB

Save the packet into:

```text
cmcb_sync/inbox_from_chatgpt/
```

Then run:

```bash
python scripts/cmcb_bidirectional_sync.py import-chatgpt
```
